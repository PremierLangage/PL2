import { DefaultComponent } from "../../resources/exercice-list/components/default/default.component";

export declare type ProviderExerciceListTemplateTypes = DefaultComponent;

export declare type ProviderExerciceListTemplateKeys = "default" | string;