import { DefaultComponent } from "../../resources/templates/components/default/default.component";

export declare type ProviderActivityTemplateTypes = DefaultComponent;

export declare type ProviderActivityTemplateKeys = "default" | string;