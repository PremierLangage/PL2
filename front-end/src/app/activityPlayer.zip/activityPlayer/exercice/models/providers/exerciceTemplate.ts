import { DefaultComponent } from "../../resources/templates/components/default/default.component";

export declare type ProviderExerciceTemplateTypes = DefaultComponent;

export declare type ProviderExerciceTemplateKeys = "default" | string;